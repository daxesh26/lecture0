import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Download, Loader2, Gem, Upload, XCircle, Image, CheckCircle, Scale, Users, FileText, Grid, Plus } from 'lucide-react';

// --- Firebase Setup (MANDATORY BOILERPLATE) ---
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { setLogLevel } from 'firebase/app'; 

// Global environment variables
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

const MAX_RETRIES = 5;
const MAX_UPLOADED_IMAGES = 4;
const NUM_IMAGES_TO_GENERATE_PER_PRODUCT = 2; // Default variations per uploaded image

// --- STUDIO OPTIONS ---
const PRODUCT_CATEGORIES = [
    { name: "Jewelry", icon: "💎" },
    { name: "Electronics", icon: "📱" },
    { name: "Apparel", icon: "👕" },
    { name: "Custom", icon: "✨" },
];

// UPDATED BACKGROUND_OPTIONS with specific jewelry photography themes
const BACKGROUND_OPTIONS = [
  // E-commerce Standard
  { name: "Minimal White E-commerce", color: "bg-white", text: "White", previewUrl: "https://placehold.co/60x60/ffffff/000000?text=White" },
  
  // Pastel Tones
  { name: "Pastel Pink", color: "bg-pink-300", text: "P. Pink", previewUrl: "https://placehold.co/60x60/f9a8d4/333333?text=P.+Pink" },
  { name: "Pastel Peach", color: "bg-amber-100", text: "P. Peach", previewUrl: "https://placehold.co/60x60/fde68a/333333?text=P.+Peach" },
  { name: "Pastel Blue", color: "bg-blue-300", text: "P. Blue", previewUrl: "https://placehold.co/60x60/93c5fd/333333?text=P.+Blue" },
  { name: "Pastel Mint", color: "bg-emerald-200", text: "P. Mint", previewUrl: "https://placehold.co/60x60/a7f3d0/333333?text=P.+Mint" },
  { name: "Luxury Matte Pastel", color: "bg-purple-200", text: "Matte", previewUrl: "https://placehold.co/60x60/d8b4fe/333333?text=Matte" },

  // Fabric and Texture
  { name: "Black Velvet", color: "bg-black", text: "B. Velvet", previewUrl: "https://placehold.co/60x60/000000/ffffff?text=B.+Velvet" },
  { name: "Grey Velvet", color: "bg-gray-600", text: "G. Velvet", previewUrl: "https://placehold.co/60x60/4b5563/ffffff?text=G.+Velvet" },
  { name: "Beige Suede", color: "bg-amber-500", text: "Suede", previewUrl: "https://placehold.co/60x60/f59e0b/ffffff?text=Suede" },
  { name: "Satin Background", color: "bg-cyan-300", text: "Satin", previewUrl: "https://placehold.co/60x60/67e8f9/333333?text=Satin" },
  { name: "Fabric Texture", color: "bg-gray-400", text: "Fabric", previewUrl: "https://placehold.co/60x60/9ca3af/ffffff?text=Fabric" },

  // Lifestyle and Model Shots
  { name: "Skin-tone Lifestyle", color: "bg-orange-200", text: "Skin", previewUrl: "https://placehold.co/60x60/fed7aa/333333?text=Skin" },
  { name: "Model Hand Shot", color: "bg-amber-700", text: "Hand", previewUrl: "https://placehold.co/60x60/b45309/ffffff?text=Hand" },
  { name: "Model Neck Shot", color: "bg-red-700", text: "Neck", previewUrl: "https://placehold.co/60x60/b91c1c/ffffff?text=Neck" },
  { name: "Lifestyle Soft Background", color: "bg-lime-200", text: "Soft", previewUrl: "https://placehold.co/60x60/e9ffb5/333333?text=Soft" },

  // Custom Option
  { name: "Custom (Prompt se likhein)", color: "bg-purple-900/50 border-dashed", text: "Custom", previewUrl: "https://placehold.co/60x60/7c3aed/ffffff?text=Custom" },
];

const ASPECT_RATIOS = [
    { ratio: "1:1", description: "Square (E-commerce Default)" },
    { ratio: "4:5", description: "Portrait (Instagram/TikTok)" },
    { ratio: "16:9", description: "Landscape (Web Banner)" },
];

const HUMAN_MODELS = [
    { id: 1, type: "Woman", description: "A young female model with dark hair wearing an elegant black dress." },
    { id: 2, type: "Man", description: "A male model with a clean shaven look wearing a formal dark suit." },
];

const MODEL_EMOJIS = ['👩🏻', '👨🏽']; 


export default function App() {
  // --- New State for Multiple Uploads ---
  const [uploadedImages, setUploadedImages] = useState([]); // Array of {id, base64, mimeType, url}
  const [selectedProductCategory, setSelectedProductCategory] = useState(PRODUCT_CATEGORIES[0].name);

  // State for Generation Options
  const [prompt, setPrompt] = useState("");
  const [selectedBackground, setSelectedBackground] = useState(BACKGROUND_OPTIONS[0].name); 
  const [customBackgroundPrompt, setCustomBackgroundPrompt] = useState("");
  const [selectedRatio, setSelectedRatio] = useState(ASPECT_RATIOS[0].ratio);
  const [selectedModelId, setSelectedModelId] = useState(null); 
  const [numVariationsPerProduct, setNumVariationsPerProduct] = useState(NUM_IMAGES_TO_GENERATE_PER_PRODUCT);

  // Output State
  // generatedImages: [{ url, base64, sourceProductId, sourceIndex, variationIndex, mimeType }]
  const [generatedImages, setGeneratedImages] = useState([]); 
  const [selectedImageIndex, setSelectedImageIndex] = useState(null); // Index in the generatedImages array
  
  // UI/Loading
  const [currentGenerationProgress, setCurrentGenerationProgress] = useState({ current: 0, total: 0 });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [error, setError] = useState(null);
  const [isAuthReady, setIsAuthReady] = useState(false); 
  const [authStatus, setAuthStatus] = useState("Initializing..."); 
  
  // Ref for file input
  const fileInputRef = useRef(null);


  // 1. Firebase Initialization & Auth
  useEffect(() => {
    setLogLevel('debug');
    
    if (Object.keys(firebaseConfig).length === 0) {
      setAuthStatus("No Firebase config found. Running app without full auth.");
      setIsAuthReady(true);
      return;
    }
    
    try {
      const app = initializeApp(firebaseConfig);
      const initializedAuth = getAuth(app);
      getFirestore(app); 
      
      const authenticate = async () => {
        try {
          setAuthStatus("Authenticating...");
          if (initialAuthToken) {
            await signInWithCustomToken(initializedAuth, initialAuthToken);
            setAuthStatus("Authenticated with token.");
          } else {
            await signInAnonymously(initializedAuth);
            setAuthStatus("Authenticated Anonymously.");
          }
        } catch (authError) {
          console.error("Firebase Auth Error (Critical):", authError);
          setAuthStatus(`Authentication Failed: ${authError.code}`);
          setError("App failed to initialize user session. Check console.");
        } finally {
          setIsAuthReady(true);
        }
      };
      authenticate();
    } catch (e) {
      console.error("Firebase Initialization Error (Critical):", e);
      setAuthStatus(`Initialization Error: ${e.message}`);
      setError("App component failed to initialize Firebase.");
      setIsAuthReady(true); 
    }
  }, []);


  // 2. Image Upload/Remove Handlers
  const handleImageUpload = (event) => {
    const files = Array.from(event.target.files);
    
    if (files.length === 0) return;

    setError(null);
    setGeneratedImages([]); 
    setSelectedImageIndex(null); 
    
    const newImages = [];
    const availableSlots = MAX_UPLOADED_IMAGES - uploadedImages.length;
    
    files.slice(0, availableSlots).forEach((file, index) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result.split(',')[1];
          const newImage = {
            id: `img-${Date.now()}-${index}`,
            base64: base64,
            mimeType: file.type,
            url: reader.result,
          };
          
          setUploadedImages(prev => {
            // Check again to ensure we don't exceed MAX_UPLOADED_IMAGES due to async nature
            if (prev.length < MAX_UPLOADED_IMAGES) {
                return [...prev, newImage];
            }
            return prev;
          });
        };
        reader.readAsDataURL(file);
      } else {
        setError("Kripya sirf valid image files (JPEG, PNG) upload karein.");
      }
    });

    // Clear the file input so the same file can be uploaded again if needed
    if (fileInputRef.current) {
        fileInputRef.current.value = ""; 
    }
  };

  const removeUploadedImage = (id) => {
    setUploadedImages(prev => prev.filter(img => img.id !== id));
    setGeneratedImages([]); 
    setSelectedImageIndex(null);
    setError(null);
  };
  
  // 3. Prompt Suggestion (Image Analysis on the first uploaded image)
  const suggestPrompt = async () => {
    if (uploadedImages.length === 0) {
      setError("Pehle apni product image upload karein.");
      return;
    }

    const firstImage = uploadedImages[0];

    setError(null);
    setIsSuggesting(true);

    const systemInstruction = `You are an expert product photo retoucher focusing on the ${selectedProductCategory} category. Your task is to analyze the uploaded image of a product and write a concise, descriptive prompt (in English) that highlights the item, its material, and suggests professional enhancements (e.g., 'with enhanced clarity, studio lighting, and a soft bokeh background'). Do no include the output in any markdown block or extra commentary. Just the prompt text.`;
    
    const payload = {
        contents: [
            {
                role: "user",
                parts: [
                    { text: `Suggest a detailed prompt to professionally enhance this ${selectedProductCategory} image.` },
                    {
                        inlineData: {
                            mimeType: firstImage.mimeType,
                            data: firstImage.base64
                        }
                    }
                ]
            }
        ],
        systemInstruction: {
            parts: [{ text: systemInstruction }]
        },
    };

    const apiKey = "";
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`;

    for (let j = 0; j < MAX_RETRIES; j++) {
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`Prompt suggestion failed: HTTP error ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
            }

            const result = await response.json();
            const suggestedText = result.candidates?.[0]?.content?.parts?.[0]?.text || `A highly polished ${selectedProductCategory} item on a clean background.`;
            
            setPrompt(suggestedText.trim());
            setError(null);
            setIsSuggesting(false);
            return;

        } catch (e) {
            console.error(`Attempt ${j + 1} failed for Prompt Suggestion:`, e);
            if (j < MAX_RETRIES - 1) {
                const delay = Math.pow(2, j) * 1000 + Math.random() * 500;
                await new Promise(resolve => setTimeout(resolve, delay));
            } else {
                setError(`Prompt suggestion mein error: ${e.message}`);
                setIsSuggesting(false);
            }
        }
    }
  };


  // 4. Image Modification (Image-to-Image Generation)
  const modifyImage = async () => {
    if (uploadedImages.length === 0) {
      setError("Pehle image upload karein.");
      return;
    }
    if (!prompt.trim()) {
      setError("Scene Description (prompt) likhein.");
      return;
    }

    setError(null);
    setIsGenerating(true);
    setGeneratedImages([]); 
    setSelectedImageIndex(null);
    
    const totalImagesToGenerate = uploadedImages.length * numVariationsPerProduct;
    setCurrentGenerationProgress({ current: 0, total: totalImagesToGenerate });
    
    // --- Constructing the final prompt based on selections ---
    
    // Background Segment
    let backgroundSegment;
    if (selectedBackground === "Custom (Prompt se likhein)") {
        backgroundSegment = customBackgroundPrompt ? `, set against a scene described as: ${customBackgroundPrompt}.` : '';
    } else {
        const bgOption = BACKGROUND_OPTIONS.find(opt => opt.name === selectedBackground);
        // CRUCIAL: Using the selected background name in the prompt
        backgroundSegment = bgOption ? `, set against a ${bgOption.name} backdrop.` : ''; 
    }

    // Human Model Segment
    const selectedModel = HUMAN_MODELS.find(m => m.id === selectedModelId);
    let modelSegment = selectedModel ? `The product is featured with a human model: ${selectedModel.description}. ` : '';

    // Aspect Ratio segment
    const ratioInstruction = `The final image should reflect an aspect ratio of ${selectedRatio}. `;

    const baseEnhancementPrompt = `Modify the uploaded image. Product Category: ${selectedProductCategory}. Focus on: "${prompt}". ${modelSegment} ${backgroundSegment} ${ratioInstruction} Ensure the core product item remains unchanged, but enhance the photo quality, apply professional lightroom effects, perfect the lighting, and blend seamlessly with the new scene. Photorealistic, 8k, cinematic lighting, enhanced details, high polish.`;
    
    // --- Sequential Generation (Iterate through all uploaded products) ---
    const generatedResults = [];
    const apiKey = ""; 
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${apiKey}`;
    
    let globalCounter = 0;

    for (const [productIndex, product] of uploadedImages.entries()) {
        for (let i = 0; i < numVariationsPerProduct; i++) {
            globalCounter++;
            setCurrentGenerationProgress({ current: globalCounter, total: totalImagesToGenerate });

            const variation = i > 0 ? `, capture the scene from a slightly different angle or apply a subtle light shift (Variation ${i+1}).` : '.';
            const finalPrompt = baseEnhancementPrompt + variation;

            const payload = {
                contents: [
                    {
                        role: "user",
                        parts: [
                            { text: finalPrompt },
                            {
                                inlineData: {
                                    mimeType: product.mimeType,
                                    data: product.base64
                                }
                            }
                        ]
                    }
                ],
                generationConfig: {
                    responseModalities: ['TEXT', 'IMAGE']
                },
            };

            let lastError = null;
            let success = false;

            for (let j = 0; j < MAX_RETRIES; j++) {
                try {
                    const response = await fetch(apiUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });

                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(`HTTP error! status: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
                    }

                    const result = await response.json();
                    const base64Data = result.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;

                    if (base64Data) {
                        const imgUrl = `data:image/png;base64,${base64Data}`;
                        generatedResults.push({ 
                            url: imgUrl, 
                            base64: base64Data, 
                            sourceProductId: product.id,
                            sourceIndex: productIndex,
                            variationIndex: i,
                            mimeType: 'image/png' // Generated image is typically PNG
                        });
                        setGeneratedImages([...generatedResults]); 
                        success = true;
                        break; 
                    } else {
                        lastError = new Error(`No image data returned for attempt ${j + 1}`);
                    }
                } catch (e) {
                    lastError = e;
                    console.error(`Attempt ${j + 1} failed for Product ${productIndex + 1}, Variation ${i + 1}:`, e);
                    if (j < MAX_RETRIES - 1) {
                        const delay = Math.pow(2, j) * 1000 + Math.random() * 500;
                        await new Promise(resolve => setTimeout(resolve, delay));
                    }
                }
            }
        }
    }

    setIsGenerating(false);
    if (generatedResults.length === 0) {
        setError(`Image modification failed after multiple attempts.`);
    }
  };


  // 5. Download Logic
  const downloadImage = () => {
    if (selectedImageIndex === null || generatedImages.length === 0) {
      setError("Download karne ke liye pehle ek image select karein.");
      return;
    }

    const selectedImage = generatedImages[selectedImageIndex];
    
    try {
        const link = document.createElement('a');
        // Naming convention: enhanced-product-[source_index]-[variation_index].png
        const defaultFilename = `enhanced-product-P${selectedImage.sourceIndex + 1}-V${selectedImage.variationIndex + 1}.png`;
        
        link.href = selectedImage.url; 
        link.download = defaultFilename;
        
        document.body.appendChild(link);
        link.click();
        
        document.body.removeChild(link);
        setError(null);

    } catch (e) {
        console.error("Download failed:", e);
        setError("Download karne mein koi error aa gaya: " + e.message);
    }
  };


  // --- Render Logic ---
  const isCustomBackgroundSelected = selectedBackground === "Custom (Prompt se likhein)";
  const isReadyToGenerate = uploadedImages.length > 0 && prompt.trim() && !isGenerating && !isSuggesting;
  const aspectRatioClass = selectedRatio === "1:1" ? "aspect-square" : 
                           selectedRatio === "4:5" ? "aspect-[4/5]" : 
                           selectedRatio === "16:9" ? "aspect-[16/9]" : "aspect-square"; // Default to 1:1

  // Calculate total number of slots in the grid (generated images + placeholders)
  const totalSlots = uploadedImages.length * numVariationsPerProduct;

  if (!isAuthReady) {
    return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center font-sans">
            <div className="flex flex-col items-center p-8 bg-gray-800 rounded-xl shadow-lg">
                <Loader2 size={32} className="animate-spin text-lime-400 mb-3" />
                <p className="text-lg font-semibold text-gray-200">Studio Load ho raha hai...</p>
                <p className="text-sm text-gray-400 mt-1">Status: {authStatus}</p>
            </div>
        </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-start p-4 font-sans text-gray-100">
      
      <div className="w-full max-w-5xl bg-gray-800 rounded-2xl shadow-2xl overflow-hidden border border-gray-700 mt-8">
        
        {/* Header */}
        <div className="bg-gray-900 p-4 sm:p-6 border-b border-gray-700">
          <h1 className="text-xl sm:text-2xl font-bold tracking-wider text-lime-400">Binduxi Jewels AI Studio</h1>
        </div>

        {/* Main Content Area */}
        <div className="p-4 sm:p-6 flex flex-col lg:flex-row gap-6">
          
          {/* Controls Panel (Left/Top) */}
          <div className="lg:w-1/2 flex flex-col gap-4">
            
            {/* 1. Product Category */}
            <div className="bg-gray-700 p-4 rounded-lg">
                <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-1">
                    <Gem size={14} /> Product Category
                </label>
                <select 
                    value={selectedProductCategory}
                    onChange={(e) => setSelectedProductCategory(e.target.value)}
                    className="w-full p-2 bg-gray-600 border border-gray-500 rounded-md text-gray-200"
                    disabled={isGenerating}
                >
                    {PRODUCT_CATEGORIES.map(cat => (
                        <option key={cat.name} value={cat.name}>
                            {cat.icon} {cat.name}
                        </option>
                    ))}
                </select>
                <p className="text-xs text-gray-400 mt-2">Isse AI ko sahi tarah se focus karne mein madad milegi.</p>
            </div>

            {/* 2. Image Upload Area */}
            <div className="bg-gray-700 p-4 rounded-lg">
                <label className="text-sm font-semibold text-gray-400 flex items-center justify-between mb-2">
                    <span className="flex items-center gap-2">
                        <Upload size={14} />
                        Product Images Upload Karein (1 se {MAX_UPLOADED_IMAGES} tak)
                    </span>
                    <span className="text-xs text-gray-400">{uploadedImages.length} / {MAX_UPLOADED_IMAGES}</span>
                </label>
                
                <div className="flex flex-wrap gap-2 mb-3">
                    {uploadedImages.map(img => (
                        <div key={img.id} className="relative w-16 h-16 rounded-lg overflow-hidden border-2 border-lime-400 shadow-md">
                            <img src={img.url} alt="Uploaded Product" className="w-full h-full object-cover" />
                            <button
                                onClick={() => removeUploadedImage(img.id)}
                                className="absolute top-0 right-0 p-0.5 bg-red-600/80 rounded-bl-lg text-white hover:bg-red-700 transition-colors"
                                disabled={isGenerating}
                            >
                                <XCircle size={14} />
                            </button>
                        </div>
                    ))}
                    {uploadedImages.length < MAX_UPLOADED_IMAGES && (
                        <label 
                            htmlFor="file-upload"
                            className="w-16 h-16 border-2 border-dashed border-gray-500 rounded-lg flex flex-col items-center justify-center text-gray-400 cursor-pointer hover:border-lime-400 hover:text-lime-400 transition-colors"
                            title="Image Upload Karein"
                        >
                            <Plus size={20} />
                            <span className="text-xs">Add</span>
                        </label>
                    )}
                </div>
                <input
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={handleImageUpload}
                    ref={fileInputRef}
                    className="hidden"
                    id="file-upload"
                    multiple // Allow multiple file selection
                    disabled={isGenerating || uploadedImages.length >= MAX_UPLOADED_IMAGES}
                />
            </div>
            

            {/* 3. Scene Description (Prompt) */}
            <div className="bg-gray-700 p-4 rounded-lg">
                <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-1">
                    Scene Description
                    <button
                        onClick={suggestPrompt}
                        disabled={uploadedImages.length === 0 || isSuggesting || isGenerating}
                        className="text-xs text-lime-400 hover:text-lime-300 disabled:opacity-50"
                        title="AI se prompt suggest karein (Pahli image par aadharit)"
                    >
                        {isSuggesting ? 'Analyzing...' : 'Suggest'}
                    </button>
                </label>
                <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={3}
                    className="w-full p-2 bg-gray-900 border border-gray-600 rounded-md focus:border-lime-400 focus:ring-1 focus:ring-lime-400 text-gray-200 transition-all resize-none"
                    placeholder="Apne product aur scene ke baare mein likhein (Jaise: High-end diamond ring on a velvet cushion...)"
                    disabled={isGenerating || isSuggesting || uploadedImages.length === 0}
                />
            </div>

            {/* 4. Backgrounds (Visual Grid) */}
            <div className="bg-gray-700 p-4 rounded-lg">
                <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-2">
                    <Image size={14} />
                    Background Selection
                </label>
                <div className="flex flex-wrap gap-2">
                    {BACKGROUND_OPTIONS.map((bg, index) => (
                        <button
                            key={bg.name}
                            onClick={() => {
                                setSelectedBackground(bg.name);
                                if (!bg.name.includes('Custom')) setCustomBackgroundPrompt('');
                            }}
                            className={`w-16 h-16 rounded-md border-2 overflow-hidden flex items-center justify-center text-center transition-all shadow-md relative
                                ${selectedBackground === bg.name ? 'border-lime-400 ring-2 ring-lime-700' : 'border-gray-500 hover:border-lime-500'}
                                ${bg.color}
                            `}
                            title={bg.name}
                            disabled={isGenerating || uploadedImages.length === 0}
                        >
                            {/* Visual Preview Image */}
                            <img 
                                src={bg.previewUrl} 
                                alt={bg.name}
                                className="w-full h-full object-cover transition-opacity duration-300 rounded-md"
                                onError={(e) => {
                                    // Fallback to text/color if image fails to load
                                    e.target.style.display = 'none'; 
                                }}
                            />
                            {/* Fallback Text Overlay */}
                            <span 
                                className={`absolute inset-0 flex items-center justify-center text-xs font-semibold p-1 ${
                                    bg.color.includes('black') || bg.color.includes('gray-600') || bg.color.includes('red-700') || bg.color.includes('amber-700') || bg.color.includes('purple-900') ? 'text-white' : 'text-gray-900'
                                }`}
                                style={{
                                    // Show text for custom option or if image failed to load
                                    display: bg.previewUrl.includes('Custom') ? 'flex' : 'none' 
                                }}
                            >
                                {bg.text}
                            </span>
                        </button>
                    ))}
                </div>
                {isCustomBackgroundSelected && (
                    <textarea
                        value={customBackgroundPrompt}
                        onChange={(e) => setCustomBackgroundPrompt(e.target.value)}
                        rows={2}
                        className="w-full p-2 mt-3 bg-gray-900 border border-lime-600 rounded-md focus:border-lime-400 focus:ring-1 focus:ring-lime-400 text-gray-200 transition-all resize-none"
                        placeholder="Apne custom background ko detail mein likhein (Jaise: Tropical beach at sunset with soft shadows...)"
                        disabled={isGenerating || uploadedImages.length === 0}
                    />
                )}
            </div>

            {/* 5. Aspect Ratio & Num Variations & Models */}
            <div className="bg-gray-700 p-4 rounded-lg">
                <div className="grid grid-cols-3 gap-4">
                    <div>
                        <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-1">
                            <Scale size={14} /> Ratio
                        </label>
                        <select 
                            value={selectedRatio}
                            onChange={(e) => setSelectedRatio(e.target.value)}
                            className="w-full p-2 bg-gray-600 border border-gray-500 rounded-md text-gray-200 text-sm"
                            disabled={isGenerating || uploadedImages.length === 0}
                        >
                            {ASPECT_RATIOS.map(ar => (
                                <option key={ar.ratio} value={ar.ratio}>
                                    {ar.ratio}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-1">
                            <Grid size={14} /> Variations
                        </label>
                        <select
                            value={numVariationsPerProduct}
                            onChange={(e) => setNumVariationsPerProduct(parseInt(e.target.value, 10))}
                            className="w-full p-2 bg-gray-600 border border-gray-500 rounded-md text-gray-200 text-sm"
                            disabled={isGenerating || uploadedImages.length === 0}
                        >
                            {[1, 2, 3, 4].map(num => (
                                <option key={num} value={num}>
                                    {num}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-1">
                            <Users size={14} /> Model
                        </label>
                        <select 
                            value={selectedModelId || ''}
                            onChange={(e) => setSelectedModelId(e.target.value ? parseInt(e.target.value, 10) : null)}
                            className="w-full p-2 bg-gray-600 border border-gray-500 rounded-md text-gray-200 text-sm"
                            disabled={isGenerating || uploadedImages.length === 0}
                        >
                            <option value="">None</option>
                            {HUMAN_MODELS.map((model, index) => (
                                <option key={model.id} value={model.id}>
                                    {MODEL_EMOJIS[index]} {model.type}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            {/* Generate Button (The main action) */}
            <button
                onClick={modifyImage}
                disabled={!isReadyToGenerate}
                className={`flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-bold text-gray-900 shadow-xl transition-all transform active:scale-95 disabled:opacity-30 mt-4
                  ${isGenerating ? 'bg-lime-300' : 'bg-lime-400 hover:bg-lime-500'}
                `}
              >
                {isGenerating ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    Generating {currentGenerationProgress.current}/{currentGenerationProgress.total} Images...
                  </>
                ) : (
                  <>
                    Images Generate Karein ({totalSlots || 0})
                  </>
                )}
            </button>
            
            {error && (
                <div className="bg-red-900/50 border-l-4 border-red-500 text-red-300 p-3 rounded-md text-sm mt-4">
                    <p>Error: {error}</p>
                </div>
            )}
            
          </div>

          {/* Image Display Area (Right/Bottom) */}
          <div className="lg:w-1/2 min-h-[300px] flex flex-col gap-4">
              
            {/* Display Area */}
            <div className={`w-full bg-gray-900 border-4 border-gray-700 rounded-2xl shadow-inner flex flex-col items-center justify-center p-4 overflow-hidden relative`}>
                
                {generatedImages.length === 0 && !isGenerating && (
                    <div className="flex flex-col items-center p-8 text-gray-500">
                        <Image size={48} className="mb-4" />
                        <p className="font-semibold text-center">Apne product ko naya roop dein</p>
                        <p className="text-sm mt-1 text-center text-gray-600">Images upload karein aur settings set karein.</p>
                    </div>
                )}

                {/* Generated Image Grid */}
                {(generatedImages.length > 0 || isGenerating) && (
                    <div className="grid grid-cols-2 gap-4 w-full h-full">
                        {[...Array(totalSlots)].map((_, index) => {
                            const image = generatedImages[index];
                            
                            if (image) {
                                // Already generated image
                                return (
                                    <div 
                                        key={index}
                                        onClick={() => setSelectedImageIndex(index)}
                                        className={`relative ${aspectRatioClass} rounded-lg overflow-hidden cursor-pointer transition-all duration-200 
                                            ${selectedImageIndex === index ? 'border-4 border-lime-400 shadow-xl ring-4 ring-lime-700' : 'border-2 border-gray-500 hover:border-lime-600'}
                                        `}
                                    >
                                        <img 
                                            src={image.url} 
                                            alt={`Generated Image ${index + 1}`} 
                                            className="w-full h-full object-cover bg-gray-800"
                                        />
                                        <div className="absolute top-1 right-1 bg-black/50 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                                            P{image.sourceIndex + 1} V{image.variationIndex + 1}
                                        </div>
                                        {selectedImageIndex === index && (
                                            <div className="absolute inset-0 flex items-center justify-center bg-lime-500/30">
                                                <CheckCircle size={40} className="text-white drop-shadow-lg" />
                                            </div>
                                        )}
                                    </div>
                                );
                            } else if (isGenerating) {
                                // Placeholder for images still generating
                                return (
                                    <div key={index} className={`bg-gray-700 rounded-lg flex items-center justify-center text-gray-500 text-sm ${aspectRatioClass}`}>
                                        <Loader2 size={24} className="animate-spin mr-2" />
                                        <p>Generating...</p>
                                    </div>
                                );
                            }
                            return null;
                        })}
                    </div>
                )}
            </div>

            {/* Download Button */}
            <button
                onClick={downloadImage}
                disabled={isGenerating || selectedImageIndex === null || generatedImages.length === 0}
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-bold text-gray-900 bg-lime-600 hover:bg-lime-700 shadow-md transition-all transform active:scale-95 disabled:opacity-30"
                title="Download the currently selected image"
              >
                <Download size={20} />
                Selected Image Download Karein (P{selectedImageIndex !== null ? generatedImages[selectedImageIndex].sourceIndex + 1 : '-'} V{selectedImageIndex !== null ? generatedImages[selectedImageIndex].variationIndex + 1 : '-'})
              </button>
          </div>

        </div>
      </div>
    </div>
  );
}